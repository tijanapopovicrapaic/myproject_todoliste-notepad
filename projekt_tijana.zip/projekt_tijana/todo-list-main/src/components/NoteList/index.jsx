import React from "react";
import Note from "../Note";

const Notes = ({ notes, editNote, onDelete }) => {
  return (
    <div className="notepadSection">
        {notes.length === 0 ? (
          <p className="noNotes">No notes here yet . . .</p>
        ) : (
          notes.map((note) => (
              <Note key={note.id} note={note} editNote={editNote} onDelete={onDelete} />
          ))
        )}
    </div>
  );
};

export default Notes;
