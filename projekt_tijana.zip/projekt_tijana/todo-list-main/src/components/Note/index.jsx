import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPenToSquare, faTrashCan } from "@fortawesome/free-solid-svg-icons";
import AddNote from "../AddNote";

const Note = ({ note, editNote, onDelete }) => {
  const [isOpen, setIsOpen] = useState(false);

  const closeModal = () => {
    setIsOpen(false);
  };

  const handleDelete = () => {
    
    onDelete(note.id);
  };

  return (
    <div className={note.type ? `note ${note.type.toLowerCase()}` : "note"}>
      <div className="titleMarkSection">
        <div className="titleSection">
          <p>Title:</p>
          <h3 className="noteTitle">{note.title}</h3>
        </div>
        <div className="marks">
          <FontAwesomeIcon
            icon={faPenToSquare}
            className="editMark"
            onClick={() => setIsOpen(true)}
          />
          <FontAwesomeIcon
            icon={faTrashCan}
            className="deleteMark"
            onClick={handleDelete}
          />
        </div>
      </div>
      <div className="noteContent">{note.content}</div>
      {isOpen && (
        <AddNote
          closeModal={closeModal}
          isOpen={isOpen}
          savedData={note}
          modifiedNote={editNote}
        />
      )}
    </div>
  );
};

export default Note;
