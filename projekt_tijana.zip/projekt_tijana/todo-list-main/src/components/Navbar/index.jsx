import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-center">
        <Link to="/" className="navbar-link">
          Todo
        </Link>
        <Link to="/notepad" className="navbar-link">
          Notepad
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
