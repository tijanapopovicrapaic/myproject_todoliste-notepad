import React, { useState } from "react";
import Modal from "react-modal";
import Select from "react-select";



const AddNote = ({ closeModal, isOpen, modifiedNote, savedData }) => {
  const typeOptions = [
    { value: "Work", label: "Work" },
    { value: "Travel", label: "Travel" },
    { value: "Shopping", label: "Shopping" },
  ];

  const groupedOption = [
    {
      label: "Type",
      options: typeOptions,
    },
  ];

  const [title, setTitle] = useState(savedData ? savedData.title : "");
  const [content, setContent] = useState(savedData ? savedData.content : "");
  const [type, setType] = useState(savedData ? savedData.type : null);

  const handleAdd = () => {
    if (title.trim() === "") return;
    if (content.trim() === "") return;
    let newNote = {
      id: savedData && savedData.id,
      title,
      content,
      type,
    };
    if (!savedData) {
      newNote.id = Date.now();
      modifiedNote(newNote);
    } else {
      modifiedNote(savedData.id, newNote);
    }

    closeModal();
  };

  return (
    <div className="addNoteModal">
      <Modal
        isOpen={isOpen}
        onRequestClose={closeModal}
        contentLabel="Add a note"
        className="openedModal"
      >
        <h2>Add a note</h2>
        <form>
          <div>
            <label>Title:</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div>
            <label>Content:</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="textarea"
            />
          </div>
          <label>Type:</label>
          <Select
            value={type ? { value: type, label: type } : null}
            onChange={(selectedOption) =>
              setType(selectedOption ? selectedOption.value : null)
            }
            options={groupedOption}
            className="selectSection"
          />
          <div className="buttonGroup">
            <button className="addNote" onClick={handleAdd}>
              Add
            </button>
            <button className="cancelNote" onClick={closeModal}>
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AddNote;
