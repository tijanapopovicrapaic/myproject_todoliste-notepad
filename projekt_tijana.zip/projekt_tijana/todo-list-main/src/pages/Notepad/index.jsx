import React, { useEffect, useState } from "react";
import Notes from "../../components/NoteList/index";
import AddNote from "../../components/AddNote";

const Notepad = () => {
  const savedNotes = JSON.parse(localStorage.getItem("notes")) || [];

  const [notes, setNotes] = useState(savedNotes);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  const addNewNote = (newNote) => {
    setNotes([...notes, newNote]);
  };

  const editNote = (noteId, updatedNote) => {
    const newNotes = notes.map((note) => {
      if (note.id === noteId) {
        return updatedNote;
      }
      return note;
    });
    setNotes(newNotes);
  };

  const closeModal = () => {
    setIsOpen(false);
  };

  const deleteTask = (noteId) => {
    const updatedNotes = notes.filter((note) => note.id !== noteId);
    setNotes(updatedNotes);
  };

  return (
    <div className="notepadSection">
      <div className="headerSection">
        <h1 className="header">Notes</h1>
        <button className="addNoteButton" onClick={() => setIsOpen(true)}>
          +
        </button>
      </div>
      <div className="line"></div>
      <Notes notes={notes} editNote={editNote} onDelete={deleteTask} />
      {isOpen && (
        <AddNote
          closeModal={closeModal}
          isOpen={isOpen}
          modifiedNote={addNewNote}
        />
      )}
    </div>
  );
};

export default Notepad;
