import React, { useState, useEffect } from "react";
import TodoList from "../../components/TodoList/index";

function Todo() {
  const savedTodos = JSON.parse(localStorage.getItem("todos")) || [];

  const [todos, setTodos] = useState(savedTodos);
  const [taskText, setTaskText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddButtonDisabled, setIsAddButtonDisabled] = useState(true);
  const searchedTodos = todos.filter((task) =>
    task.text.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  const addTask = () => {
    if (taskText.trim() === "") return;
    const newTask = {
      id: Date.now(),
      text: taskText,
      completed: false,
    };
    setTodos([...todos, newTask]);
    setTaskText("");
    setIsAddButtonDisabled(true);
  };

  const deleteTask = (taskId) => {
    const updatedTodos = todos.filter((task) => task.id !== taskId);
    setTodos(updatedTodos);
  };

  const editTask = (taskId, newText) => {
    const updatedTodos = todos.map((task) => {
      if (task.id === taskId) {
        return { ...task, text: newText };
      }
      return task;
    });
    setTodos(updatedTodos);
  };

  const handleTaskText = (e) => {
    const value = e.target.value;
    setTaskText(value);
    setIsAddButtonDisabled(value === "");
  };

  return (
    <div>
      <h1 className="header">TO DO LIST</h1>
      <input
        type="text"
        placeholder="Add a new task"
        value={taskText}
        onChange={handleTaskText}
      />
      <button
        onClick={addTask}
        disabled={isAddButtonDisabled}
        className={isAddButtonDisabled ? "addButtonDisabled" : "addButton"}
      >
        +
      </button>
      <div>
        <input
          className="input-search"
          type="text"
          placeholder="Search tasks"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      <TodoList
        todos={searchedTodos}
        deleteTask={deleteTask}
        onEdit={editTask}
      />
    </div>
  );
}

export default Todo;
