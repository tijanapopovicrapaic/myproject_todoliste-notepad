import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import TodoList from "./pages/Todo/index";
import Notepad from "./pages/Notepad/index";
import Navbar from "./components/Navbar";
import './App.css'

function App() {
  return (
    <div className="app">
      <Navbar/>
      <Routes>
        <Route path="/" element={<TodoList />} />
        <Route path="/notepad" element={<Notepad />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  );
}

export default App;
